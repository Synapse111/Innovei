
import React from "react";
import Header from "@/components/innovei/Header";
import HeroSection from "@/components/innovei/HeroSection";
import AdvantagesGrid from "@/components/innovei/AdvantagesGrid";
import ProcessSection from "@/components/innovei/ProcessSection";
import GamificationSection from "@/components/innovei/GamificationSection";
import ResultsSection from "@/components/innovei/ResultsSection";
import CallToAction from "@/components/innovei/CallToAction";

const Index = () => {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <HeroSection />
        <AdvantagesGrid />
        <ProcessSection />
        <GamificationSection />
        <ResultsSection />
        <CallToAction />
      </main>
      
      <footer className="bg-black text-gray-400 py-8">
        <div className="container text-center">
          <p>© {new Date().getFullYear()} Innovei | Desenvolvido pelo Instituto Synapse</p>
          <p className="mt-2 text-sm">
            Transformando ideias em inovação real com inteligência e estratégia
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
