import React, { useState, useCallback, useRef } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import PresentationControls from '@/components/presentation/PresentationControls';
import Slide from '@/components/presentation/Slide';
import HeroSection from '@/components/innovei/HeroSection';
import ModulesSection from '@/components/innovei/ModulesSection';
import PlatformFeatures from '@/components/innovei/PlatformFeatures';
import ProcessSection from '@/components/innovei/ProcessSection';
import GamificationSection from '@/components/innovei/GamificationSection';
import ResultsSection from '@/components/innovei/ResultsSection';
import PricingPlans from '@/components/innovei/PricingPlans';
import AdditionalServicesSection from '@/components/innovei/AdditionalServicesSection';

const Presentation = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const touchStartX = useRef<number | null>(null);
  const isMobile = useIsMobile();

  const handlePrevSlide = useCallback(() => {
    setCurrentSlide(prev => Math.max(0, prev - 1));
  }, []);

  const handleNextSlide = useCallback(() => {
    setCurrentSlide(prev => Math.min(slides.length - 1, prev + 1));
  }, []);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;

    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartX.current - touchEndX;

    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        handleNextSlide();
      } else {
        handlePrevSlide();
      }
    }

    touchStartX.current = null;
  };

  const slides = [
    {
      id: 'hero',
      component: <HeroSection />,
      className: 'bg-black'
    },
    {
      id: 'modules',
      component: <ModulesSection />,
      className: 'bg-black'
    },
    {
      id: 'features',
      component: <PlatformFeatures />,
      className: 'bg-black'
    },
    {
      id: 'process',
      component: <ProcessSection />,
      className: 'bg-gradient-to-b from-black to-gray-900'
    },
    {
      id: 'gamification',
      component: <GamificationSection />,
      className: 'bg-black'
    },
    {
      id: 'results',
      component: <ResultsSection />,
      className: 'bg-black'
    },
    {
      id: 'plans',
      component: <PricingPlans />,
      className: 'bg-black'
    },
    {
      id: 'additional-services',
      component: <AdditionalServicesSection />,
      className: 'bg-black'
    }
  ];

  React.useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight' || event.key === 'Space') {
        handleNextSlide();
      } else if (event.key === 'ArrowLeft') {
        handlePrevSlide();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [handleNextSlide, handlePrevSlide]);

  return (
    <div 
      className="relative w-full h-screen overflow-hidden bg-black"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {slides.map((slide, index) => (
        <Slide 
          key={slide.id} 
          isActive={currentSlide === index}
          className={slide.className}
        >
          {slide.component}
        </Slide>
      ))}

      <PresentationControls
        currentSlide={currentSlide}
        totalSlides={slides.length}
        onPrevSlide={handlePrevSlide}
        onNextSlide={handleNextSlide}
        isMobile={isMobile}
      />
    </div>
  );
};

export default Presentation;
