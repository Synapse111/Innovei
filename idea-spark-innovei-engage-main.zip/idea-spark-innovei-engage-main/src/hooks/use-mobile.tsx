export function useIsTouchDevice() {
  const [isTouch, setIsTouch] = React.useState(false);
  const isTouchDevice = useIsTouchDevice();
const isMobile = useIsMobile();
const shouldDisableSwipe = isMobile && isTouchDevice;

  React.useEffect(() => {
    setIsTouch('ontouchstart' in window || navigator.maxTouchPoints > 0);
  }, []);

  return isTouch;


}
