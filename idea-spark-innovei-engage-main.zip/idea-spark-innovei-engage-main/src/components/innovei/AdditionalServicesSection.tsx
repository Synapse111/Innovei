
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { ZoomIn } from "lucide-react";

type AdditionalService = {
  name: string;
  price: string;
};

const AdditionalServicesSection = () => {
  const additionalServices: AdditionalService[] = [{
    name: "Módulo Incentivo à Inovação",
    price: "R$249 / mês"
  }, {
    name: "Hora capacitação (treinamento)",
    price: "R$59,90"
  }, {
    name: "Hora personalização (técnico execução)",
    price: "R$299"
  }, {
    name: "Compra de mais usuários (50 Acessos)",
    price: "R$499 / mês"
  }];

  return (
    <div className="w-full min-h-screen flex flex-col items-center justify-center px-4 py-8">
      <h2 className="text-4xl font-bold text-center text-innovei-green mb-12">SERVIÇOS ADICIONAIS</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        {additionalServices.map((service, index) => (
          <Dialog key={index}>
            <DialogTrigger asChild>
              <Card className="bg-black/80 border-innovei-green hover:scale-105 transition-transform duration-300 cursor-pointer group">
                <CardContent className="p-8 relative">
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center z-10">
                    <ZoomIn className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="text-2xl font-bold text-innovei-green mb-6">{service.name}</h4>
                  <p className="text-3xl font-bold text-innovei-green mt-auto">
                    {service.price}
                  </p>
                </CardContent>
              </Card>
            </DialogTrigger>
            <DialogContent className="max-w-4xl bg-black/95 border-none">
              <Card className="bg-black/80 border-innovei-green">
                <CardContent className="p-8">
                  <h3 className="text-4xl font-bold text-innovei-green mb-6">{service.name}</h3>
                  <p className="text-5xl font-bold text-innovei-green mt-6">
                    {service.price}
                  </p>
                </CardContent>
              </Card>
            </DialogContent>
          </Dialog>
        ))}
      </div>
    </div>
  );
};

export default AdditionalServicesSection;
