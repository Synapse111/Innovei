import React from 'react';
import { Medal, Trophy, Star, TrendingUp, Coins } from "lucide-react";
import { Card } from "@/components/ui/card";
const GamificationSection: React.FC = () => {
  return <section className="py-16">
      <div className="container">
        <h2 className="text-3xl font-bold mb-2 text-center text-innovei-white">Gamificação com Propósito</h2>
        <p className="text-xl text-gray-500 mb-12 text-center max-w-2xl mx-auto">
          Engaje sua equipe com um sistema de recompensas que gera resultados reais
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card className="bg-gradient-to-br from-black to-innovei-dark p-8 border-innovei-green/20 text-white text-center flex flex-col items-center">
            <div className="bg-innovei-green/20 p-4 rounded-full mb-4">
              <Coins className="h-10 w-10 text-innovei-green" />
            </div>
            <h3 className="text-xl font-bold mb-2">Sistema de Moedas</h3>
            <p className="text-gray-300">
              Incentive a participação através de moedas virtuais que podem ser usadas para patrocinar 
              e apoiar ideias inovadoras
            </p>
          </Card>
          
          <Card className="bg-gradient-to-br from-black to-innovei-dark p-8 border-innovei-green/20 text-white text-center flex flex-col items-center">
            <div className="bg-innovei-green/20 p-4 rounded-full mb-4">
              <Trophy className="h-10 w-10 text-innovei-green" />
            </div>
            <h3 className="text-xl font-bold mb-2">Rankings e Competições</h3>
            <p className="text-gray-300">
              Promova competições saudáveis com leaderboards que destacam os colaboradores mais 
              inovadores e participativos
            </p>
          </Card>
          
          <Card className="bg-gradient-to-br from-black to-innovei-dark p-8 border-innovei-green/20 text-white text-center flex flex-col items-center">
            <div className="bg-innovei-green/20 p-4 rounded-full mb-4">
              <Star className="h-10 w-10 text-innovei-green" />
            </div>
            <h3 className="text-xl font-bold mb-2">Reconhecimento</h3>
            <p className="text-gray-300">
              Reconheça as melhores ideias com um sistema de premiação que valoriza a contribuição 
              de cada colaborador
            </p>
          </Card>
        </div>
        
        <div className="mt-12 bg-gradient-to-r from-innovei-green/20 to-transparent p-6 rounded-xl">
          <div className="flex items-center gap-4">
            <TrendingUp className="text-innovei-green h-8 w-8" />
            <div>
              <h4 className="text-xl font-bold">Quem inova, avança.</h4>
              <p className="text-gray-600">
                Na Innovei, a gamificação tem propósito: transformar a cultura organizacional e gerar resultados mensuráveis.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default GamificationSection;