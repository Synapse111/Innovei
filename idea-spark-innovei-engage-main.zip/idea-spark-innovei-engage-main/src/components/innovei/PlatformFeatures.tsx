import React from 'react';
import Zoom from 'react-medium-image-zoom';
import 'react-medium-image-zoom/dist/styles.css';

import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious
} from "@/components/ui/carousel";

import { useIsMobile } from "@/hooks/useIsMobile"; // Detecta largura da tela

const PlatformFeatures = () => {
  const isMobile = useIsMobile();

  const features = [
    {
      title: "Gestão do Diagnóstico",
      image: "/lovable-uploads/e21ec12d-8d67-47fc-adcf-2c9694013110.png",
      description: "Acompanhe e gerencie o progresso dos diagnósticos de inovação em tempo real."
    },
    {
      title: "Avaliação de Resultados",
      image: "/lovable-uploads/487ee1c7-1f41-4e44-aaee-7d8f1d150e8e.png",
      description: "Visualize métricas e indicadores de desempenho do programa de inovação."
    },
    {
      title: "Gestão de Colaboradores",
      image: "/lovable-uploads/51b32c24-954a-4636-9f13-8526269030ee.png",
      description: "Acompanhe a participação e engajamento dos colaboradores no programa."
    },
    {
      title: "Configuração de Questionários",
      image: "/lovable-uploads/92de0d66-c185-4b9f-ab46-153d25aa7e32.png",
      description: "Configure e personalize questionários de avaliação de inovação."
    },
    {
      title: "Análise de Dados",
      image: "/lovable-uploads/bdf06f30-dd10-4ecd-98f0-63302204973b.png",
      description: "Visualize e analise dados de inovação através de gráficos e relatórios interativos."
    }
  ];

  // Prevenir swipe ao usar o zoom
  const stopSwipe = (e: React.TouchEvent | React.MouseEvent) => {
    e.stopPropagation();
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-8 bg-black/95">
      <h2 className="text-3xl sm:text-4xl font-bold text-innovei-green mb-8 sm:mb-12 text-center">
        Funcionalidades da Plataforma
      </h2>

      <Carousel
        opts={{
          dragFree: false,
          draggable: !isMobile, // desativa swipe no mobile para evitar conflitos com zoom
          loop: false,
        }}
        className="w-full max-w-6xl"
      >
        <CarouselContent>
          {features.map((feature, index) => (
            <CarouselItem key={index}>
              <Card className="bg-black/80 border-none text-white rounded-xl">
                <CardContent className="p-4 sm:p-6 space-y-4 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xl sm:text-2xl font-bold text-innovei-green text-center sm:text-left break-words">
                      {feature.title}
                    </h3>
                    <p className="text-gray-300 text-sm sm:text-base mt-2 text-center sm:text-left break-words">
                      {feature.description}
                    </p>
                  </div>

                  <div
                    onTouchStart={stopSwipe}
                    onMouseDown={stopSwipe}
                    className="w-full flex justify-center items-center"
                  >
                    <Zoom>
                      <img
                        src={feature.image}
                        alt={feature.title}
                        className="w-full max-h-[50vh] object-contain rounded-lg shadow-lg"
                      />
                    </Zoom>
                  </div>
                </CardContent>
              </Card>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious />
        <CarouselNext />
      </Carousel>
    </div>
  );
};

export default PlatformFeatures;
