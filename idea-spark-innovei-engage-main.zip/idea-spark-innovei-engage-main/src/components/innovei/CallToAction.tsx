
import React from 'react';
import PricingPlans from './PricingPlans';

const CallToAction = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center">
      <PricingPlans />
    </div>
  );
};

export default CallToAction;
