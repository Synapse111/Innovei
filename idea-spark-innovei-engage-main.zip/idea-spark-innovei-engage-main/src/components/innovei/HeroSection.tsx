import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import WaveBackground from "./WaveBackground";
import InnoveiLogo from "./Logo";
const HeroSection: React.FC = () => {
  return <section className="min-h-[80vh] flex items-center py-16 relative overflow-hidden bg-black text-white">
      <WaveBackground className="opacity-50" />
      
      <div className="container mx-auto px-4 z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
              Transforme ideias em{" "}
              <span className="text-innovei-green">inovação real</span>
            </h1>
            
            <p className="text-lg md:text-xl text-gray-300 mb-8">
              A plataforma que diagnostica, estrutura e impulsiona a cultura 
              de inovação dentro das organizações — de forma gamificada, 
              estratégica e mensurável.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              
              
              
            </div>
            
            <div className="mt-8 flex items-center">
              <div className="flex -space-x-4">
                {[1, 2, 3, 4].map(index => <div key={index} className="w-10 h-10 rounded-full border-2 border-black bg-gray-800" />)}
              </div>
              <p className="ml-4 text-gray-400">
                Mais de <span className="text-innovei-green font-bold">700</span> empresas confiam na Innovei
              </p>
            </div>
          </div>
          
          <div className="order-1 md:order-2 flex justify-center innovei-float">
            <div className="relative">
              <div className="absolute inset-0 bg-innovei-green/20 blur-2xl rounded-full"></div>
              <InnoveiLogo size="xl" className="text-6xl relative z-10" />
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default HeroSection;