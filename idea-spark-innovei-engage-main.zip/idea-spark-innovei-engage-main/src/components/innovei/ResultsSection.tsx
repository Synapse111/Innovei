
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { TrendingUp, DollarSign, Lightbulb, Users } from "lucide-react";
import StatsCounter from './StatsCounter';
import { Card, CardContent } from "@/components/ui/card";

const pieData = [
  { name: 'Redução de Custos', value: 35 },
  { name: 'Produtividade', value: 25 },
  { name: 'Satisfação', value: 20 },
  { name: 'Novos Produtos', value: 20 },
];

const barData = [
  { name: 'Ideia', antes: 15, depois: 55 },
  { name: 'Engajamento', antes: 20, depois: 65 },
  { name: 'Implementação', antes: 10, depois: 45 },
  { name: 'ROI', antes: 25, depois: 70 },
];

const COLORS = ['#00FF7F', '#00CCAA', '#00AA88', '#008866'];

const ResultsSection: React.FC = () => {
  return (
    <section className="py-16 bg-black text-white">
      <div className="container">
        <h2 className="text-3xl font-bold mb-2 text-center">Resultados Concretos</h2>
        <p className="text-xl text-gray-400 mb-12 text-center max-w-2xl mx-auto">
          Empresas que adotaram a plataforma Innovei já colheram benefícios significativos
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-12">
          <Card className="bg-innovei-dark border-innovei-green/20">
            <CardContent className="p-6 text-center">
              <DollarSign className="h-10 w-10 text-innovei-green mx-auto mb-2" />
              <StatsCounter 
                end={35} 
                suffix="%" 
                className="text-3xl text-innovei-green" 
              />
              <p className="text-gray-400 text-sm">Redução de Custos Operacionais</p>
            </CardContent>
          </Card>
          
          <Card className="bg-innovei-dark border-innovei-green/20">
            <CardContent className="p-6 text-center">
              <Lightbulb className="h-10 w-10 text-innovei-green mx-auto mb-2" />
              <StatsCounter 
                end={85} 
                suffix="%" 
                className="text-3xl text-innovei-green" 
              />
              <p className="text-gray-400 text-sm">Aumento na Geração de Ideias</p>
            </CardContent>
          </Card>
          
          <Card className="bg-innovei-dark border-innovei-green/20">
            <CardContent className="p-6 text-center">
              <Users className="h-10 w-10 text-innovei-green mx-auto mb-2" />
              <StatsCounter 
                end={70} 
                suffix="%" 
                className="text-3xl text-innovei-green" 
              />
              <p className="text-gray-400 text-sm">Incremento no Engajamento</p>
            </CardContent>
          </Card>
          
          <Card className="bg-innovei-dark border-innovei-green/20">
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-10 w-10 text-innovei-green mx-auto mb-2" />
              <StatsCounter 
                end={42} 
                suffix="%" 
                className="text-3xl text-innovei-green" 
              />
              <p className="text-gray-400 text-sm">ROI em Processos de Inovação</p>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
          <div className="bg-innovei-dark rounded-xl p-6 border border-innovei-green/20">
            <h3 className="text-xl font-bold mb-4 text-center">Distribuição de Resultados</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          <div className="bg-innovei-dark rounded-xl p-6 border border-innovei-green/20">
            <h3 className="text-xl font-bold mb-4 text-center">Antes vs Depois da Innovei</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={barData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="antes" fill="#444444" name="Antes" />
                  <Bar dataKey="depois" fill="#00FF7F" name="Depois" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ResultsSection;
