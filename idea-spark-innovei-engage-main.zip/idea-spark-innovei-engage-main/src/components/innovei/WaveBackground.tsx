
import React from 'react';

const WaveBackground: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div className={`absolute inset-0 overflow-hidden -z-10 ${className}`}>
      <div className="absolute w-full h-full">
        {Array.from({ length: 20 }).map((_, index) => (
          <div 
            key={index} 
            className="absolute w-full opacity-20"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100 - 50}%`,
              height: `${Math.random() * 2 + 1}px`,
              width: `${Math.random() * 50 + 50}%`,
              transform: `rotate(${Math.random() * 360}deg)`,
              background: 'linear-gradient(90deg, transparent, #00FF7F, transparent)',
              boxShadow: '0 0 10px #00FF7F, 0 0 20px #00FF7F',
              animation: `wave ${Math.random() * 10 + 15}s ease-in-out infinite alternate`
            }}
          />
        ))}
      </div>
      <style>
        {`
        @keyframes wave {
          0% { transform: translateX(-10%) rotate(0deg) scaleX(0.9); }
          50% { transform: translateX(10%) rotate(3deg) scaleX(1.1); }
          100% { transform: translateX(-10%) rotate(-3deg) scaleX(0.9); }
        }
        `}
      </style>
    </div>
  );
};

export default WaveBackground;
