import React from 'react';
import { Card, CardContent } from "@/components/ui/card";

const ModulesSection = () => {
  const modules = [
    {
      number: "01",
      title: "Gestão da Inovação",
      description:
        "É o módulo central para captura, avaliação e desenvolvimento de ideias, centralizando todo o processo e permitindo o acompanhamento e engajamento dos colaboradores.",
    },
    {
      number: "02",
      title: "Diagnóstico",
      description:
        "O módulo de Diagnóstico permite que empresas realizem avaliações detalhadas de projetos, obtendo insights valiosos de empresas, clientes e colaboradores para orientar estratégias de inovação e melhorar práticas internas e externas.",
    },
    {
      number: "03",
      title: "Incentivo à Inovação",
      description:
        "O Incentivo à Inovação foi inspirado nos conceitos do livro \"Os 10 Tipos de Inovação\" de Larry Keeley, que destaca diferentes abordagens de inovação. Este módulo ajuda as empresas a criarem estratégias inovadoras e táticas com um foco holístico em inovação.",
    }
  ];

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-8">
      <h2 className="text-4xl font-bold text-innovei-green mb-12">MÓDULOS</h2>
      <div className="grid md:grid-cols-3 gap-8 w-full max-w-7xl">
        {modules.map((module) => (
          <Card
            key={module.number}
            className="group hover:scale-105 transition-transform duration-300 bg-black/80 border-none text-white"
          >
            <CardContent className="p-6">
              <div className="text-8xl font-bold text-innovei-green mb-4">
                {module.number}
              </div>
              <h3 className="text-2xl font-bold mb-4 text-innovei-green">
                {module.title}
              </h3>
              <p className="text-gray-300">{module.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ModulesSection;
