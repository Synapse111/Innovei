import React from 'react';

const InnoveiLogo: React.FC<{
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
}> = ({
  className = '',
  size = "md"
}) => {
  const sizeClasses = {
    sm: "h-10 w-auto",
    md: "h-16 w-auto",
    lg: "h-24 w-auto",
    xl: "h-32 w-auto"
  };

  return (
    <div className={`flex items-center ${className}`}>
      <img
        src="https://raw.githubusercontent.com/souzagabriell/innovei/main/LOGO%20INNOVEI_COLORIDA.png"
        alt="Innovei Logo"
        className={`${sizeClasses[size]} object-contain max-w-full`}
      />
    </div>
  );
};

export default InnoveiLogo;
