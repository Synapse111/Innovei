
import React from "react";
import { 
  UsersRound, 
  TrendingUp, 
  BarChart4, 
  ClipboardList, 
  Star, 
  Lightbulb, 
  Settings, 
  Award
} from "lucide-react";
import FeatureCard from "./FeatureCard";

const AdvantagesGrid: React.FC = () => {
  const advantages = [
    {
      icon: <UsersRound size={24} />,
      title: "CULTURA DE INOVAÇÃO COLABORATIVA",
      description: "Promova a colaboração e a co-criação entre equipes multidisciplinares"
    },
    {
      icon: <BarChart4 size={24} />,
      title: "ANÁLISE PROFUNDA E RELATÓRIOS DETALHADOS",
      description: "Obtenha insights com dados e métricas sobre o processo de inovação"
    },
    {
      icon: <TrendingUp size={24} />,
      title: "ENGAJAMENTO E GAMIFICAÇÃO",
      description: "Sistema de recompensas que motiva a participação contínua"
    },
    {
      icon: <Lightbulb size={24} />,
      title: "INOVAÇÃO HOLÍSTICA E ESTRATÉGICA",
      description: "Abordagem integrada aplicada a produtos, processos e modelos de negócio"
    },
    {
      icon: <ClipboardList size={24} />,
      title: "CENTRALIZAÇÃO E ORGANIZAÇÃO",
      description: "Gerencie todo o ciclo de vida da inovação em um único lugar"
    },
    {
      icon: <Settings size={24} />,
      title: "FLEXIBILIDADE E PERSONALIZAÇÃO",
      description: "Adapte a plataforma às necessidades específicas da sua empresa"
    },
    {
      icon: <Star size={24} />,
      title: "AVALIAÇÃO ESTRUTURADA E FEEDBACK CONTÍNUO",
      description: "Mecanismos de feedback que aprimoram continuamente as ideias"
    },
    {
      icon: <Award size={24} />,
      title: "RECONHECIMENTO E CRESCIMENTO PROFISSIONAL",
      description: "Valorize e reconheça os colaboradores mais inovadores"
    }
  ];

  return (
    <section className="py-16 bg-white relative overflow-hidden">
      <div className="container">
        <h2 className="text-3xl font-bold mb-2 text-center">Vantagens da Plataforma Innovei</h2>
        <p className="text-xl text-gray-500 mb-12 text-center max-w-2xl mx-auto">
          Uma solução completa para transformar a cultura de inovação da sua empresa
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {advantages.map((advantage, index) => (
            <FeatureCard
              key={index}
              icon={advantage.icon}
              title={advantage.title}
              description={advantage.description}
              className="h-full"
            />
          ))}
        </div>
      </div>

      <div className="absolute inset-0 -z-10">
        <div 
          className="absolute bottom-0 left-0 right-0 h-[500px] w-full innovei-wave"
          style={{
            background: 'linear-gradient(180deg, transparent 0%, rgba(0, 255, 127, 0.05) 100%)'
          }}
        />
      </div>
    </section>
  );
};

export default AdvantagesGrid;
