
import React from "react";
import { Button } from "@/components/ui/button";
import WaveBackground from "./WaveBackground";
import InnoveiLogo from "./Logo";

const Header: React.FC = () => {
  return (
    <header className="bg-black text-white py-4 sticky top-0 z-50">
      <div className="container flex justify-between items-center">
        <InnoveiLogo size="sm" className="text-2xl" />
        
        <nav className="hidden md:flex items-center space-x-6">
          <a href="#recursos" className="text-gray-200 hover:text-innovei-green transition-colors">Recursos</a>
          <a href="#processo" className="text-gray-200 hover:text-innovei-green transition-colors">Processo</a>
          <a href="#gamificacao" className="text-gray-200 hover:text-innovei-green transition-colors">Gamificação</a>
          <a href="#resultados" className="text-gray-200 hover:text-innovei-green transition-colors">Resultados</a>
          <a href="#sobre" className="text-gray-200 hover:text-innovei-green transition-colors">Sobre</a>
        </nav>
        
        <div>
          <Button className="bg-innovei-green hover:bg-innovei-green/80 text-black">
            Comece agora
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
