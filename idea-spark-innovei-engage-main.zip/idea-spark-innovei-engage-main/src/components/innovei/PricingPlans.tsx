import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { ZoomIn } from "lucide-react";

type PlanFeature = {
  text: string;
  highlight?: boolean;
};

type Plan = {
  name: string;
  features: PlanFeature[];
  monthlyPrice?: string;
  implementationPrice?: string;
};

const PricingPlans = () => {
  const plans: Plan[] = [
    {
      name: "BORN",
      features: [{
        text: "Módulo Gestão da Inovação"
      }, {
        text: "100 Usuários"
      }, {
        text: "1 Administrador"
      }, {
        text: "Capacitação 2h (treinamento)"
      }, {
        text: "Suporte via ticket"
      }, {
        text: "Planejamento e organização necessidades"
      }, {
        text: "Prioridade na participação das visitas do Inovatour"
      }],
      monthlyPrice: "R$999",
      implementationPrice: "R$1.499"
    }, {
      name: "BASIC",
      features: [{
        text: "Módulo Gestão da Inovação"
      }, {
        text: "500 usuários"
      }, {
        text: "2 Administradores"
      }, {
        text: "Capacitação 4h (treinamento)"
      }, {
        text: "Suporte via ticket"
      }, {
        text: "Planejamento e organização necessidades"
      }, {
        text: "20% OFF para ser associado ao Instituto Synapse"
      }, {
        text: "4 acessos à área VIP do Connect Week Summit"
      }, {
        text: "10 Ingressos Arena"
      }, {
        text: "Prioridade na participação das visitas do Inovatour"
      }],
      monthlyPrice: "R$3.299",
      implementationPrice: "R$1.499"
    }, {
      name: "PRIME",
      features: [{
        text: "Módulo Gestão da Inovação"
      }, {
        text: "Módulo Diagnóstico"
      }, {
        text: "1000 usuários"
      }, {
        text: "4 Administradores"
      }, {
        text: "Capacitação 4h (treinamento)"
      }, {
        text: "Suporte Premium"
      }, {
        text: "Planejamento e organização necessidades"
      }, {
        text: "50% OFF para ser associado ao Instituto Synapse"
      }, {
        text: "6 acessos à área VIP do Connect Week Summit"
      }, {
        text: "20 Ingressos Arena"
      }, {
        text: "Agendamento de visita personalizada Inovatour"
      }],
      monthlyPrice: "R$4.599",
      implementationPrice: "R$4.499"
    }, {
      name: "UNLIMITED",
      features: [{
        text: "Módulo Gestão da Inovação"
      }, {
        text: "Módulo Diagnóstico"
      }, {
        text: "Módulo Incentivo à Inovação"
      }, {
        text: "Usuários ilimitados"
      }, {
        text: "Administradores ilimitados"
      }, {
        text: "Capacitação ilimitada (treinamento)"
      }, {
        text: "Suporte Premium"
      }, {
        text: "Planejamento e organização necessidades"
      }, {
        text: "Associação gratuita ao Instituto Synapse"
      }, {
        text: "20% OFF Cota CWSummit"
      }, {
        text: "8 acessos à área VIP do Connect Week Summit"
      }, {
        text: "40 Ingressos Arena"
      }, {
        text: "Agendamento de visita personalizada Inovatour"
      }],
      monthlyPrice: "SOB CONSULTA"
    }
  ];

  return (
    <div className="w-full px-4 py-8">
      <h2 className="text-4xl font-bold text-center text-innovei-green mb-12">PLANOS</h2>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-7xl mx-auto">
        {plans.map(plan => (
          <Dialog key={plan.name}>
            <DialogTrigger asChild>
              <Card className="bg-black/80 border-innovei-green hover:scale-105 transition-transform duration-300 cursor-pointer group">
                <CardContent className="p-6 relative">
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center z-10">
                    <ZoomIn className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-innovei-green mb-6">{plan.name}</h3>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="text-white text-sm flex items-center gap-2">
                        {feature.text}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-auto">
                    {plan.monthlyPrice && (
                      <div className="text-innovei-green font-bold">
                        <div className="text-sm">INVESTIMENTO MENSAL</div>
                        <div className="text-2xl">{plan.monthlyPrice}</div>
                      </div>
                    )}
                    {plan.implementationPrice && (
                      <div className="text-innovei-green font-bold mt-2">
                        <div className="text-sm">IMPLEMENTAÇÃO</div>
                        <div className="text-2xl">{plan.implementationPrice}</div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </DialogTrigger>
            <DialogContent className="max-w-4xl bg-black/95 border-none">
              <Card className="bg-black/80 border-innovei-green">
                <CardContent className="p-6">
                  <h3 className="text-3xl font-bold text-innovei-green mb-6">{plan.name}</h3>
                  <ul className="space-y-4 mb-6">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="text-white text-lg flex items-center gap-2">
                        {feature.text}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-auto">
                    {plan.monthlyPrice && (
                      <div className="text-innovei-green font-bold">
                        <div className="text-xl">INVESTIMENTO MENSAL</div>
                        <div className="text-4xl">{plan.monthlyPrice}</div>
                      </div>
                    )}
                    {plan.implementationPrice && (
                      <div className="text-innovei-green font-bold mt-4">
                        <div className="text-xl">IMPLEMENTAÇÃO</div>
                        <div className="text-4xl">{plan.implementationPrice}</div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </DialogContent>
          </Dialog>
        ))}
      </div>
    </div>
  );
};

export default PricingPlans;
