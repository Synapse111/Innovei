
import React, { ReactNode } from 'react';
import { Card, CardContent } from "@/components/ui/card";

interface FeatureCardProps {
  icon: ReactNode;
  title: string;
  description?: string;
  className?: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ 
  icon, 
  title, 
  description, 
  className = '' 
}) => {
  return (
    <Card className={`border-innovei-green/20 hover:border-innovei-green transition-all duration-300 backdrop-blur-sm bg-white/90 hover:shadow-md hover:shadow-innovei-green/20 ${className}`}>
      <CardContent className="p-6 flex items-start gap-4">
        <div className="bg-innovei-green/10 rounded-xl p-3 text-innovei-green">
          {icon}
        </div>
        <div>
          <h3 className="font-bold text-lg mb-1">{title}</h3>
          {description && (
            <p className="text-gray-600 text-sm">{description}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default FeatureCard;
