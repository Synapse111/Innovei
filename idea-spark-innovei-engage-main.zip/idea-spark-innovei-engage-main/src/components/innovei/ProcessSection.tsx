
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Lightbulb, Microscope, LineChart, Rocket } from "lucide-react";

const ProcessSection: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="container">
        <h2 className="text-3xl font-bold mb-2 text-center">Inovação como Processo Contínuo</h2>
        <p className="text-xl text-gray-500 mb-12 text-center max-w-2xl mx-auto">
          A Innovei estrutura a inovação como uma prática estratégica e sustentável
        </p>

        <div className="relative">
          {/* Connecting line */}
          <div className="absolute left-1/2 top-8 bottom-8 w-1 bg-innovei-green/30 -translate-x-1/2 hidden md:block"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="md:pr-12 md:text-right relative">
              <div className="hidden md:block absolute right-0 top-8 w-4 h-4 bg-innovei-green rounded-full -translate-x-1/2 translate-y-1/2 z-10"></div>
              <Card className="bg-white shadow-md border-innovei-green/20 hover:border-innovei-green transition-all duration-300">
                <CardContent className="p-6 flex flex-col md:flex-row-reverse md:items-start gap-4">
                  <div className="bg-innovei-green/10 rounded-full p-3 flex items-center justify-center">
                    <Microscope className="h-8 w-8 text-innovei-green" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-1">Diagnóstico</h3>
                    <p className="text-gray-600">
                      Avalie o estado atual de inovação da sua empresa com ferramentas de 
                      diagnóstico detalhadas e personalizadas para o seu setor.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="md:pl-12 md:text-left relative">
              <div className="hidden md:block absolute left-0 top-8 w-4 h-4 bg-innovei-green rounded-full translate-x-1/2 translate-y-1/2 z-10"></div>
              <Card className="bg-white shadow-md border-innovei-green/20 hover:border-innovei-green transition-all duration-300">
                <CardContent className="p-6 flex flex-col md:flex-row md:items-start gap-4">
                  <div className="bg-innovei-green/10 rounded-full p-3 flex items-center justify-center">
                    <Lightbulb className="h-8 w-8 text-innovei-green" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-1">Ideação</h3>
                    <p className="text-gray-600">
                      Capture e desenvolva ideias com ferramentas colaborativas que estimulam 
                      a criatividade e o pensamento inovador em toda a organização.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="md:pr-12 md:text-right relative mt-8">
              <div className="hidden md:block absolute right-0 top-8 w-4 h-4 bg-innovei-green rounded-full -translate-x-1/2 translate-y-1/2 z-10"></div>
              <Card className="bg-white shadow-md border-innovei-green/20 hover:border-innovei-green transition-all duration-300">
                <CardContent className="p-6 flex flex-col md:flex-row-reverse md:items-start gap-4">
                  <div className="bg-innovei-green/10 rounded-full p-3 flex items-center justify-center">
                    <LineChart className="h-8 w-8 text-innovei-green" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-1">Gestão</h3>
                    <p className="text-gray-600">
                      Gerencie o portfólio de inovação com ferramentas para priorização, 
                      alocação de recursos e acompanhamento do progresso em tempo real.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="md:pl-12 md:text-left relative mt-8">
              <div className="hidden md:block absolute left-0 top-8 w-4 h-4 bg-innovei-green rounded-full translate-x-1/2 translate-y-1/2 z-10"></div>
              <Card className="bg-white shadow-md border-innovei-green/20 hover:border-innovei-green transition-all duration-300">
                <CardContent className="p-6 flex flex-col md:flex-row md:items-start gap-4">
                  <div className="bg-innovei-green/10 rounded-full p-3 flex items-center justify-center">
                    <Rocket className="h-8 w-8 text-innovei-green" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-1">Implementação</h3>
                    <p className="text-gray-600">
                      Transforme ideias em realidade com metodologias ágeis de implementação, 
                      ferramentas de prototipagem e frameworks para validação de conceito.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
