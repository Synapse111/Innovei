
import React from 'react';
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface PresentationControlsProps {
  currentSlide: number;
  totalSlides: number;
  onPrevSlide: () => void;
  onNextSlide: () => void;
  isMobile?: boolean;
}

const PresentationControls: React.FC<PresentationControlsProps> = ({
  currentSlide,
  totalSlides,
  onPrevSlide,
  onNextSlide,
  isMobile = false
}) => {
  return (
    <div className={`fixed ${isMobile ? 'bottom-4' : 'bottom-8'} left-1/2 -translate-x-1/2 flex items-center gap-4 bg-black/50 backdrop-blur-sm px-4 py-2 rounded-full`}>
      <Button
        variant="ghost"
        size="icon"
        onClick={onPrevSlide}
        disabled={currentSlide === 0}
        className="text-white hover:bg-white/20"
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <div className="text-white font-mono min-w-[60px] text-center">
        {currentSlide + 1} / {totalSlides}
      </div>

      <Button
        variant="ghost"
        size="icon"
        onClick={onNextSlide}
        disabled={currentSlide === totalSlides - 1}
        className="text-white hover:bg-white/20"
      >
        <ChevronRight className="h-6 w-6" />
      </Button>
    </div>
  );
};

export default PresentationControls;
