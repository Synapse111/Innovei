
import React from 'react';
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";

interface SlideProps {
  isActive: boolean;
  children: React.ReactNode;
  className?: string;
}

const Slide: React.FC<SlideProps> = ({ isActive, children, className }) => {
  return (
    <div 
      className={cn(
        "fixed inset-0 w-full h-full transition-all duration-500 ease-in-out",
        isActive ? "opacity-100 translate-x-0" : "opacity-0 translate-x-full",
        className
      )}
    >
      <ScrollArea className="h-full w-full">
        <div className="p-4 md:p-8 max-w-7xl mx-auto">
          {children}
        </div>
      </ScrollArea>
    </div>
  );
};

export default Slide;

